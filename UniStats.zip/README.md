# UniStats
A data visualization project to help students select a university by looking up institution details and comparing institutions. 
Live Demo (Currently Work in Progress) can be found here: https://d39xm282kfgdbn.cloudfront.net/
